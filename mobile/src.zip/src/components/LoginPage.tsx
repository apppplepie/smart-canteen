import React, { useState } from "react";
import { motion } from "motion/react";
import { ChevronLeft, Sparkles, User, Lock } from "lucide-react";
import { THEME } from "../config/theme";
import { login, getCurrentUser, isApiConfigured } from "../api/auth";

export type LoginUser = {
  name: string;
  id: string;
  avatar: string;
  userId?: number;
  token?: string;
};

interface LoginPageProps {
  onBack: () => void;
  onLogin: (user: LoginUser) => void;
}

export function LoginPage({ onBack, onLogin }: LoginPageProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!username.trim() || !password) return;

    if (isApiConfigured()) {
      setLoading(true);
      try {
        const { token } = await login({ username: username.trim(), password });
        const me = await getCurrentUser(token);
        onLogin({
          name: me.username,
          id: username.trim(),
          avatar: "https://picsum.photos/seed/u" + (me.id ?? username) + "/100/100",
          userId: me.id,
          token,
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : "登录失败");
      } finally {
        setLoading(false);
      }
    } else {
      // 未配置后端时 mock：学生/老师均可用于本地调试
      onLogin({
        name: "干饭王",
        id: username.trim(),
        avatar: "https://picsum.photos/seed/u1/100/100",
        userId: 1,
      });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: "100%" }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: "100%" }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="fixed inset-0 bg-white z-[100] flex flex-col"
    >
      <div className="px-6 pt-6 pb-3 sticky top-0 z-10 flex items-center">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:bg-gray-50 rounded-full transition-colors">
          <ChevronLeft size={24} />
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center px-8 pb-32 max-w-md mx-auto w-full">
        <div className="mb-12 text-center">
          <div className="w-16 h-16 bg-[#FF6B6B] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-red-500/30">
            <Sparkles className="text-white" size={32} />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">欢迎回来</h1>
          <p className="text-gray-500">登录智慧食堂，开启干饭之旅</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          {error ? (
            <div className="text-sm text-red-500 bg-red-50 border border-red-100 rounded-2xl py-3 px-4">
              {error}
            </div>
          ) : null}
          <div className="space-y-4">
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="请输入姓名"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 pl-12 pr-4 text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#FF6B6B]/20 focus:border-[#FF6B6B] transition-all"
                required
                autoComplete="name"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="password"
                placeholder="请输入密码"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 pl-12 pr-4 text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#FF6B6B]/20 focus:border-[#FF6B6B] transition-all"
                required
                autoComplete="current-password"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={!username.trim() || !password || loading}
            className="w-full text-white py-4 rounded-2xl font-bold text-lg shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-md active:scale-[0.98]"
            style={{ backgroundColor: THEME.colors.primary }}
          >
            {loading ? "登录中…" : "登录"}
          </button>
        </form>
      </div>
    </motion.div>
  );
}
